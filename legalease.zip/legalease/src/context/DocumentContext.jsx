import { createContext, useContext, useEffect, useState } from 'react';
import { api } from '../api.js';

const Ctx = createContext(null);
export const useDocs = () => useContext(Ctx);

export function DocumentProvider({ children }) {
  const [templates, setTemplates] = useState([]);
  const [error, setError] = useState('');
  const [activeDoc, setActiveDoc] = useState(null);
  useEffect(() => { api.templates().then(setTemplates).catch((e) => setError(e.message)); }, []);
  const resetDoc = () => setActiveDoc(null); // called when the template changes so old clauses never leak in
  return <Ctx.Provider value={{ templates, error, activeDoc, setActiveDoc, resetDoc }}>{children}</Ctx.Provider>;
}
