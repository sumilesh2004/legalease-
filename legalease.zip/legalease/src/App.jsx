import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar.jsx';
import Home from './pages/Home.jsx';
import TemplateLibrary from './pages/TemplateLibrary.jsx';
import Generate from './pages/Generate.jsx';
import DocumentEditor from './pages/DocumentEditor.jsx';
import Dashboard from './pages/Dashboard.jsx';

export default function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/templates" element={<TemplateLibrary />} />
        <Route path="/generate/:templateId" element={<Generate />} />
        <Route path="/editor/:id" element={<DocumentEditor />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="*" element={<main><h1>Page not found</h1></main>} />
      </Routes>
      <footer className="muted">LegalEase drafts are starting points, not legal advice. Have a lawyer review important documents.</footer>
    </>
  );
}
