import Button from './Button.jsx';

export default function ClauseEditor({ clauses, onChange }) {
  const set = (i, patch) => onChange(clauses.map((c, k) => (k === i ? { ...c, ...patch } : c)));
  return (
    <div>
      {clauses.map((c, i) => (
        <div className="card clause" key={c.id || i}>
          <input className="chead" value={c.heading} onChange={(e) => set(i, { heading: e.target.value })} aria-label="Clause heading" />
          <textarea rows={Math.max(3, c.text.split('\n').length + 1)} value={c.text} onChange={(e) => set(i, { text: e.target.value })} aria-label={`Clause text: ${c.heading}`} />
          <Button text="Remove clause" variant="ghost" onClick={() => onChange(clauses.filter((_, k) => k !== i))} />
        </div>
      ))}
      <Button text="Add clause" variant="secondary" onClick={() => onChange([...clauses, { id: 'n' + Date.now(), heading: 'New clause', text: '' }])} />
    </div>
  );
}
