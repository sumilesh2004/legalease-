import { Link } from 'react-router-dom';

export default function TemplateCard({ template }) {
  return (
    <Link to={`/generate/${template.id}`} className="card tcard">
      <span className="tag">{template.category}</span>
      <h3>{template.title}</h3>
      <p className="muted">{template.description}</p>
    </Link>
  );
}
