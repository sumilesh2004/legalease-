import { useState } from 'react';
import Button from './Button.jsx';

export default function Questionnaire({ template, onSubmit }) {
  const [step, setStep] = useState(0);
  const [ans, setAns] = useState({});
  const [err, setErr] = useState('');
  const f = template.fields[step];
  const last = step === template.fields.length - 1;
  const next = () => {
    if (!String(ans[f.name] ?? '').trim()) return setErr(`${f.label} is required`);
    setErr('');
    if (last) onSubmit(ans); else setStep(step + 1);
  };
  return (
    <div className="card">
      <p className="muted">Question {step + 1} of {template.fields.length}</p>
      <label>{f.label}
        <input key={f.name} autoFocus type={f.type} value={ans[f.name] ?? ''}
          onChange={(e) => setAns({ ...ans, [f.name]: e.target.value })}
          onKeyDown={(e) => e.key === 'Enter' && next()} />
      </label>
      {err && <p className="error">{err}</p>}
      <div className="row">
        {step > 0 && <Button text="Back" variant="secondary" onClick={() => { setErr(''); setStep(step - 1); }} />}
        <Button text={last ? 'Generate document' : 'Next'} onClick={next} />
      </div>
    </div>
  );
}
