import { useState } from 'react';

export default function SearchBar({ onSearch, initial = '', live = false }) {
  const [q, setQ] = useState(initial);
  const change = (v) => { setQ(v); if (live) onSearch(v); };
  return (
    <form className="search" onSubmit={(e) => { e.preventDefault(); onSearch(q); }}>
      <input value={q} onChange={(e) => change(e.target.value)} placeholder="Search templates, e.g. lease" aria-label="Search templates" />
      {!live && <button className="btn primary">Search</button>}
    </form>
  );
}
