import { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';

const items = [['/', 'Home'], ['/templates', 'Templates'], ['/dashboard', 'My documents']];

export default function Navbar({ logo = 'LegalEase', menuItems = items }) {
  const [dark, setDark] = useState(() => { try { return localStorage.getItem('theme') === 'dark'; } catch { return false; } });
  useEffect(() => {
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    try { localStorage.setItem('theme', dark ? 'dark' : 'light'); } catch { /* storage unavailable */ }
  }, [dark]);
  return (
    <nav className="nav">
      <b className="logo">{logo}</b>
      <div className="links">{menuItems.map(([to, l]) => <NavLink key={to} to={to} end>{l}</NavLink>)}</div>
      <button className="btn ghost" onClick={() => setDark(!dark)} aria-label="Toggle dark mode">{dark ? 'Light' : 'Dark'}</button>
    </nav>
  );
}
