export default function Button({ text, onClick, variant = 'primary', disabled, type = 'button' }) {
  return <button type={type} className={`btn ${variant}`} onClick={onClick} disabled={disabled}>{text}</button>;
}
