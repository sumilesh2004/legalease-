export default function Loading({ size = 'medium', label = 'Loading…' }) {
  return <div className="loading" role="status"><span className={`spinner ${size}`} />{label}</div>;
}
