import Button from './Button.jsx';

export default function Hero({ title, subtitle, buttonText, onClick }) {
  return <section className="hero"><h1>{title}</h1><p>{subtitle}</p><Button text={buttonText} onClick={onClick} /></section>;
}
