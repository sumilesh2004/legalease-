import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App.jsx';
import { DocumentProvider } from './context/DocumentContext.jsx';
import './styles/index.css';

createRoot(document.getElementById('root')).render(
  <BrowserRouter><DocumentProvider><App /></DocumentProvider></BrowserRouter>
);
