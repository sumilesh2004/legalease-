import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import Loading from '../components/Loading.jsx';
import Button from '../components/Button.jsx';

export default function Dashboard() {
  const [docs, setDocs] = useState(null);
  const [error, setError] = useState('');
  useEffect(() => { api.docs().then(setDocs).catch((e) => setError(e.message)); }, []);
  const remove = async (id) => {
    if (!window.confirm('Delete this document?')) return;
    try { await api.remove(id); setDocs(docs.filter((d) => d.id !== id)); } catch (e) { setError(e.message); }
  };
  return (
    <main>
      <h1>My documents</h1>
      {error && <p className="error">{error}</p>}
      {!docs && !error && <Loading />}
      {docs?.length === 0 && <p className="muted">No documents yet. <Link to="/templates">Start from a template</Link>.</p>}
      <div className="grid">
        {docs?.map((d) => (
          <div className="card" key={d.id}>
            <span className="tag">{d.status}</span>
            <h3><Link to={'/editor/' + d.id}>{d.title}</Link></h3>
            <p className="muted">Edited {new Date(d.updatedAt).toLocaleDateString()}</p>
            <Button text="Delete" variant="ghost" onClick={() => remove(d.id)} />
          </div>
        ))}
      </div>
    </main>
  );
}
