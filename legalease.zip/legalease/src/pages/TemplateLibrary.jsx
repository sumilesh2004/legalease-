import { useSearchParams } from 'react-router-dom';
import { useDocs } from '../context/DocumentContext.jsx';
import SearchBar from '../components/SearchBar.jsx';
import TemplateCard from '../components/TemplateCard.jsx';
import Loading from '../components/Loading.jsx';
import { filterTemplates } from '../utils/search.js';

const CATS = ['All', 'Business', 'Real Estate', 'Employment', 'Personal'];

export default function TemplateLibrary() {
  const { templates, error } = useDocs();
  const [params, setParams] = useSearchParams();
  const q = params.get('q') || '';
  const cat = params.get('cat') || 'All';
  const update = (patch) => setParams({ q, cat, ...patch }, { replace: true });
  const shown = filterTemplates(templates, q, cat);
  return (
    <main>
      <h1>Template library</h1>
      <SearchBar live initial={q} onSearch={(v) => update({ q: v })} />
      <div className="chips">{CATS.map((c) => <button key={c} className={`btn ${c === cat ? 'primary' : 'secondary'}`} onClick={() => update({ cat: c })}>{c}</button>)}</div>
      {error && <p className="error">Could not load templates: {error}. Is the API running on port 5001?</p>}
      {!templates.length && !error && <Loading />}
      <div className="grid">{shown.map((t) => <TemplateCard key={t.id} template={t} />)}</div>
      {templates.length > 0 && !shown.length && <p className="muted">No templates match. Try a different word or category.</p>}
    </main>
  );
}
