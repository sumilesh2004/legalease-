import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useDocs } from '../context/DocumentContext.jsx';
import { api } from '../api.js';
import ClauseEditor from '../components/ClauseEditor.jsx';
import Button from '../components/Button.jsx';
import Loading from '../components/Loading.jsx';

export default function DocumentEditor() {
  const { id } = useParams();
  const { setActiveDoc } = useDocs();
  const [doc, setDoc] = useState(null);
  const [msg, setMsg] = useState('');
  const [email, setEmail] = useState('');
  useEffect(() => { setDoc(null); api.doc(id).then((d) => { setDoc(d); setActiveDoc(d); }).catch((e) => setMsg(e.message)); }, [id]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!doc) return <main>{msg ? <p className="error">{msg}</p> : <Loading />}</main>;

  const run = (fn, ok) => async () => {
    try { const d = await fn(); if (d) { setDoc(d); setActiveDoc(d); } setMsg(ok); } catch (e) { setMsg(e.message); }
  };
  const save = (status = doc.status) => run(() => api.save(id, { title: doc.title, clauses: doc.clauses, status }), status === 'final' ? 'Marked as final' : 'Saved');

  return (
    <main>
      <input className="title" value={doc.title} onChange={(e) => setDoc({ ...doc, title: e.target.value })} aria-label="Document title" />
      <p className="muted">Status: {doc.status}{doc.signature && ` · signature request sent to ${doc.signature.email}`}</p>
      <ClauseEditor clauses={doc.clauses} onChange={(clauses) => setDoc({ ...doc, clauses })} />
      <div className="row sticky">
        <Button text="Save to dashboard" onClick={save()} />
        <Button text="Mark as final" variant="secondary" onClick={save('final')} />
        <a className="btn secondary" href={api.exportUrl(id, 'pdf')}>Export PDF</a>
        <a className="btn secondary" href={api.exportUrl(id, 'docx')}>Export DOCX</a>
      </div>
      {msg && <p role="status" className="muted">{msg}</p>}
      <section className="card">
        <h3>Send for e-signature</h3>
        <div className="row"><input type="email" placeholder="signer@example.com" value={email} onChange={(e) => setEmail(e.target.value)} aria-label="Signer email" />
          <Button text="Send request" onClick={run(() => api.sign(id, email), 'Signature request recorded')} /></div>
      </section>
      <section className="card">
        <h3>Version history</h3>
        {!doc.versions.length && <p className="muted">Versions appear here each time you save changes.</p>}
        {doc.versions.map((v, i) => (
          <div className="row between" key={i}><span>{new Date(v.savedAt).toLocaleString()}</span>
            <Button text="Restore" variant="ghost" onClick={run(() => api.revert(id, i), 'Version restored')} /></div>
        )).reverse()}
      </section>
    </main>
  );
}
