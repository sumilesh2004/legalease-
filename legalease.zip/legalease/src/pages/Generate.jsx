import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useDocs } from '../context/DocumentContext.jsx';
import { api } from '../api.js';
import Questionnaire from '../components/Questionnaire.jsx';
import Loading from '../components/Loading.jsx';

export default function Generate() {
  const { templateId } = useParams();
  const { templates, resetDoc, setActiveDoc } = useDocs();
  const nav = useNavigate();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => { resetDoc(); }, [templateId]); // eslint-disable-line react-hooks/exhaustive-deps
  const t = templates.find((x) => x.id === templateId);
  if (!t) return <main><Loading /></main>;
  const submit = async (answers) => {
    setBusy(true); setError('');
    try { const d = await api.generate(t.id, answers); setActiveDoc(d); nav('/editor/' + d.id); }
    catch (e) { setError(e.message + ' Select Generate document to retry.'); }
    finally { setBusy(false); }
  };
  return (
    <main>
      <h1>{t.title}</h1>
      {busy && <Loading label="Drafting your document…" />}
      <div hidden={busy}><Questionnaire key={t.id} template={t} onSubmit={submit} /></div>
      {error && <p className="error">{error}</p>}
    </main>
  );
}
