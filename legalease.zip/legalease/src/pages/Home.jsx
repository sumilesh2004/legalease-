import { useNavigate } from 'react-router-dom';
import Hero from '../components/Hero.jsx';
import SearchBar from '../components/SearchBar.jsx';

export default function Home() {
  const nav = useNavigate();
  return (
    <main>
      <Hero title="Draft a legal document in minutes" subtitle="Answer a few plain-language questions and get an editable first draft."
        buttonText="Browse templates" onClick={() => nav('/templates')} />
      <SearchBar onSearch={(q) => nav(`/templates?q=${encodeURIComponent(q)}`)} />
    </main>
  );
}
