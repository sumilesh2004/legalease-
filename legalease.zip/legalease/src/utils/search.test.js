import { describe, it, expect } from 'vitest';
import { filterTemplates } from './search.js';

const list = [
  { title: 'Residential Lease', category: 'Real Estate', description: 'Rent a home' },
  { title: 'Non-Disclosure Agreement', category: 'Business', description: 'Protect secrets' },
];
describe('filterTemplates', () => {
  it('ignores case', () => expect(filterTemplates(list, 'LEASE')).toHaveLength(1));
  it('filters by category', () => expect(filterTemplates(list, '', 'Business')[0].title).toMatch(/Non-Disclosure/));
  it('returns all for empty query', () => expect(filterTemplates(list)).toHaveLength(2));
  it('returns none when nothing matches', () => expect(filterTemplates(list, 'zzz')).toHaveLength(0));
});
