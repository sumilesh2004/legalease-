// Case-insensitive search across title, category and description, plus a category filter.
export function filterTemplates(list, query = '', category = 'All') {
  const q = query.trim().toLowerCase();
  return list.filter((t) =>
    (category === 'All' || t.category === category) &&
    (!q || [t.title, t.category, t.description].some((v) => v.toLowerCase().includes(q))));
}
