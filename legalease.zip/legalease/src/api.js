async function req(url, opt = {}) {
  const r = await fetch('/api' + url, { headers: { 'Content-Type': 'application/json' }, ...opt });
  if (!r.ok) {
    const e = await r.json().catch(() => ({}));
    throw new Error(e.error || `Request failed (${r.status})`);
  }
  return r.status === 204 ? null : r.json();
}
const body = (b) => ({ method: 'POST', body: JSON.stringify(b) });
export const api = {
  templates: () => req('/templates'),
  generate: (templateId, answers) => req('/generate', body({ templateId, answers })),
  docs: () => req('/documents'),
  doc: (id) => req('/documents/' + id),
  save: (id, b) => req('/documents/' + id, { method: 'PUT', body: JSON.stringify(b) }),
  remove: (id) => req('/documents/' + id, { method: 'DELETE' }),
  revert: (id, n) => req(`/documents/${id}/revert/${n}`, { method: 'POST' }),
  sign: (id, email) => req(`/documents/${id}/sign`, body({ email })),
  exportUrl: (id, format) => `/api/documents/${id}/export?format=${format}`,
};
