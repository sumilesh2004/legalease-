import test from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';

process.env.DB_FILE = path.join(os.tmpdir(), `legalease-${Date.now()}.json`);
delete process.env.ANTHROPIC_API_KEY; // force sample drafts
const { app } = await import('../server/app.js');
const srv = app.listen(0);
const base = `http://localhost:${srv.address().port}/api`;
const j = (u, o = {}) => fetch(base + u, { headers: { 'Content-Type': 'application/json' }, ...o });
test.after(() => srv.close());

let doc;
test('lists templates', async () => {
  const t = await (await j('/templates')).json();
  assert.ok(t.length >= 4);
});
test('rejects incomplete answers', async () => {
  const r = await j('/generate', { method: 'POST', body: JSON.stringify({ templateId: 'nda', answers: {} }) });
  assert.equal(r.status, 400);
});
test('generates a draft', async () => {
  const t = (await (await j('/templates')).json()).find((x) => x.id === 'nda');
  const answers = Object.fromEntries(t.fields.map((f) => [f.name, f.type === 'number' ? '2' : 'Acme']));
  const r = await j('/generate', { method: 'POST', body: JSON.stringify({ templateId: 'nda', answers }) });
  assert.equal(r.status, 201);
  doc = await r.json();
  assert.ok(doc.clauses.length > 3);
});
test('edit stores a version and can revert', async () => {
  const clauses = [{ heading: 'Only', text: 'Changed' }];
  const u = await (await j(`/documents/${doc.id}`, { method: 'PUT', body: JSON.stringify({ clauses }) })).json();
  assert.equal(u.versions.length, 1);
  const r = await (await j(`/documents/${doc.id}/revert/0`, { method: 'POST' })).json();
  assert.equal(r.clauses.length, doc.clauses.length);
});
test('exports docx and pdf', async () => {
  assert.equal((await j(`/documents/${doc.id}/export?format=docx`)).status, 200);
  const p = await j(`/documents/${doc.id}/export?format=pdf`);
  assert.equal(p.headers.get('content-type'), 'application/pdf');
});
test('validates signature email', async () => {
  assert.equal((await j(`/documents/${doc.id}/sign`, { method: 'POST', body: JSON.stringify({ email: 'bad' }) })).status, 400);
  assert.equal((await j(`/documents/${doc.id}/sign`, { method: 'POST', body: JSON.stringify({ email: 'a@b.co' }) })).status, 200);
});
