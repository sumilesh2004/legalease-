import { Router } from 'express';
import { Document, Packer, Paragraph, HeadingLevel } from 'docx';
import PDFDocument from 'pdfkit';
import { withDoc } from '../db.js';

export const router = Router();
router.get('/documents/:id/export', withDoc(async (req, res, d) => {
  const name = d.title.replace(/[^\w-]+/g, '_');
  if (req.query.format === 'docx') {
    const children = [new Paragraph({ text: d.title, heading: HeadingLevel.TITLE }),
      ...d.clauses.flatMap((c) => [new Paragraph({ text: c.heading, heading: HeadingLevel.HEADING_2 }), ...c.text.split('\n').map((l) => new Paragraph(l))])];
    const buf = await Packer.toBuffer(new Document({ sections: [{ children }] }));
    res.set({ 'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'Content-Disposition': `attachment; filename="${name}.docx"` });
    return res.send(buf);
  }
  if (req.query.format === 'pdf') {
    res.set({ 'Content-Type': 'application/pdf', 'Content-Disposition': `attachment; filename="${name}.pdf"` });
    const pdf = new PDFDocument({ margin: 56 });
    pdf.pipe(res);
    pdf.fontSize(20).text(d.title).moveDown();
    d.clauses.forEach((c) => pdf.fontSize(13).text(c.heading).fontSize(11).text(c.text).moveDown());
    return pdf.end();
  }
  res.status(400).json({ error: 'format must be pdf or docx' });
}));
