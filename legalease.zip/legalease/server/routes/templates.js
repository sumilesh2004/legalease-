import { Router } from 'express';
import { templates } from '../templates.js';

export const router = Router();
router.get('/templates', (_req, res) => res.json(templates));
router.get('/health', (_req, res) => res.json({ ok: true, ai: !!process.env.ANTHROPIC_API_KEY }));
