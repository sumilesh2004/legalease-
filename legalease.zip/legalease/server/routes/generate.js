import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import { templates } from '../templates.js';
import { generateDraft } from '../llm.js';
import { load, save } from '../db.js';

export const router = Router();
router.post('/generate', async (req, res, next) => {
  try {
    const t = templates.find((x) => x.id === req.body.templateId);
    if (!t) return res.status(404).json({ error: 'Unknown template' });
    const answers = req.body.answers || {};
    const missing = t.fields.filter((f) => !String(answers[f.name] ?? '').trim()).map((f) => f.label);
    if (missing.length) return res.status(400).json({ error: 'Please fill in: ' + missing.join(', ') });
    const clauses = await generateDraft(t, answers);
    const now = new Date().toISOString();
    const doc = { id: randomUUID(), templateId: t.id, title: t.title, status: 'draft', clauses, versions: [], signature: null, createdAt: now, updatedAt: now };
    const all = load(); all.push(doc); save(all);
    res.status(201).json(doc);
  } catch (e) { next(e); }
});
