import { Router } from 'express';
import { withDoc, touch } from '../db.js';

export const router = Router();
// Records the request only. Plug a provider (DocuSign, Dropbox Sign...) in here.
router.post('/documents/:id/sign', withDoc((req, res, d, all) => {
  const email = String(req.body.email || '');
  if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email address' });
  d.signature = { email, status: 'sent', sentAt: new Date().toISOString() };
  touch(d, all, res);
}));
