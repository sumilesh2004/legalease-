import { Router } from 'express';
import { load, save, withDoc, touch } from '../db.js';

export const router = Router();
const cleanClauses = (cl) => cl.map((c, i) => ({ id: c.id || 'c' + i, heading: String(c.heading || ''), text: String(c.text || '') }));

router.get('/documents', (_req, res) =>
  res.json(load().map(({ clauses, versions, ...meta }) => meta).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))));
router.get('/documents/:id', withDoc((_req, res, d) => res.json(d)));

router.put('/documents/:id', withDoc((req, res, d, all) => {
  const { title, clauses, status } = req.body;
  if (clauses !== undefined && !Array.isArray(clauses)) return res.status(400).json({ error: 'clauses must be an array' });
  if (clauses) { d.versions.push({ savedAt: d.updatedAt, clauses: d.clauses }); d.versions = d.versions.slice(-20); d.clauses = cleanClauses(clauses); }
  if (title) d.title = String(title);
  if (['draft', 'final'].includes(status)) d.status = status;
  touch(d, all, res);
}));

router.post('/documents/:id/revert/:n', withDoc((req, res, d, all) => {
  const v = d.versions[Number(req.params.n)];
  if (!v) return res.status(404).json({ error: 'Version not found' });
  d.versions.push({ savedAt: d.updatedAt, clauses: d.clauses });
  d.clauses = v.clauses;
  touch(d, all, res);
}));

router.delete('/documents/:id', withDoc((_req, res, d, all) => { save(all.filter((x) => x !== d)); res.status(204).end(); }));
