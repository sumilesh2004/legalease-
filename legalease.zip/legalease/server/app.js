import express from 'express';
import cors from 'cors';
import { router as templates } from './routes/templates.js';
import { router as generate } from './routes/generate.js';
import { router as documents } from './routes/documents.js';
import { router as signature } from './routes/signature.js';
import { router as exporter } from './routes/export.js';

export const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use('/api', templates, generate, documents, signature, exporter);

// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.status === 400 ? 'Invalid request body' : err.message || 'Server error' });
});
