const f = (name, label, type = 'text') => ({ name, label, type });
export const templates = [
  { id: 'nda', title: 'Non-Disclosure Agreement', category: 'Business', description: 'Protect confidential information shared between two parties.',
    fields: [f('disclosingParty', 'Disclosing party name'), f('receivingParty', 'Receiving party name'), f('purpose', 'Purpose of disclosure'), f('term', 'Term in years', 'number'), f('jurisdiction', 'Governing jurisdiction')] },
  { id: 'service', title: 'Service Agreement', category: 'Business', description: 'Define scope, payment and delivery for freelance or contract work.',
    fields: [f('client', 'Client name'), f('provider', 'Service provider name'), f('services', 'Services to be provided'), f('fee', 'Fee and payment terms'), f('jurisdiction', 'Governing jurisdiction')] },
  { id: 'lease', title: 'Residential Lease', category: 'Real Estate', description: 'Rent a home with clear rent, deposit and term.',
    fields: [f('landlord', 'Landlord name'), f('tenant', 'Tenant name'), f('address', 'Property address'), f('rent', 'Monthly rent'), f('term', 'Lease term in months', 'number'), f('jurisdiction', 'Governing jurisdiction')] },
  { id: 'employment', title: 'Employment Contract', category: 'Employment', description: 'Set out role, pay, hours and termination for a new hire.',
    fields: [f('employer', 'Employer name'), f('employee', 'Employee name'), f('role', 'Job title and duties'), f('salary', 'Salary and benefits'), f('startDate', 'Start date', 'date'), f('jurisdiction', 'Governing jurisdiction')] },
  { id: 'poa', title: 'Power of Attorney', category: 'Personal', description: 'Let someone you trust act on your behalf.',
    fields: [f('principal', 'Your full name'), f('agent', 'Agent full name'), f('powers', 'Powers granted'), f('duration', 'Duration or end date'), f('jurisdiction', 'Governing jurisdiction')] },
];
