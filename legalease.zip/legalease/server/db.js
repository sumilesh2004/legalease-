import fs from 'node:fs';
import path from 'node:path';

// JSON-file storage. DB_FILE is read on each call so tests can point it elsewhere.
const file = () => process.env.DB_FILE || path.resolve('data/db.json');
export const load = () => (fs.existsSync(file()) ? JSON.parse(fs.readFileSync(file(), 'utf8')) : []);
export const save = (d) => { fs.mkdirSync(path.dirname(file()), { recursive: true }); fs.writeFileSync(file(), JSON.stringify(d, null, 2)); };

// Route helper: loads the doc named by :id (404 if missing) and hands it to the handler.
export const withDoc = (handler) => (req, res, next) => {
  const all = load();
  const d = all.find((x) => x.id === req.params.id);
  if (!d) return res.status(404).json({ error: 'Document not found' });
  return Promise.resolve(handler(req, res, d, all)).catch(next);
};
export const touch = (d, all, res) => { d.updatedAt = new Date().toISOString(); save(all); res.json(d); };
