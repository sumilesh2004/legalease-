import Anthropic from '@anthropic-ai/sdk';

const SYSTEM = 'You are a legal drafting assistant. Reply with ONLY valid JSON: {"clauses":[{"heading":string,"text":string}]}. ' +
  'Use only the facts provided, write in clear plain-language legal style, and use [PLACEHOLDER] for any missing detail. Include a final signatures clause.';

function mock(t, a) {
  const v = (k) => a[k] || '[PLACEHOLDER]';
  const parties = t.fields.filter((x) => /name|party|landlord|tenant|client|provider|employer|employee|principal|agent/i.test(x.name)).map((x) => `${x.label}: ${v(x.name)}`).join('; ');
  const facts = t.fields.map((x) => `${x.label}: ${v(x.name)}`).join('\n');
  return [
    ['Parties', `This ${t.title} is made between the following: ${parties}.`],
    ['Key Terms', facts],
    ['Obligations', 'Each party agrees to perform its obligations in good faith and to act promptly on reasonable requests from the other party.'],
    ['Termination', 'Either party may end this agreement by giving written notice. Obligations that by nature survive termination will continue.'],
    ['Governing Law', `This agreement is governed by the laws of ${v('jurisdiction')}.`],
    ['Signatures', 'Signed by the parties on the dates written below.\n\n______________________    ______________________'],
  ].map(([heading, text], i) => ({ id: 'c' + i, heading, text }));
}

export async function generateDraft(t, answers) {
  if (!process.env.ANTHROPIC_API_KEY) return mock(t, answers);
  const client = new Anthropic();
  const r = await client.messages.create({
    model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5', max_tokens: 4000, system: SYSTEM,
    messages: [{ role: 'user', content: `Draft a ${t.title}. Facts provided by the user: ${JSON.stringify(answers)}` }],
  });
  const raw = r.content.filter((b) => b.type === 'text').map((b) => b.text).join('').replace(/```json|```/g, '').trim();
  const { clauses } = JSON.parse(raw);
  if (!Array.isArray(clauses) || !clauses.length) throw new Error('The AI returned an unusable draft. Please try again.');
  return clauses.map((c, i) => ({ id: 'c' + i, heading: String(c.heading), text: String(c.text) }));
}
