import 'dotenv/config';
import { app } from './app.js';

const port = process.env.PORT || 5001;
app.listen(port, () => console.log(`LegalEase API on http://localhost:${port} (AI: ${process.env.ANTHROPIC_API_KEY ? 'live' : 'sample drafts'})`));
